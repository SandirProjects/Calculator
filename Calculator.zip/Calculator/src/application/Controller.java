package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import java.math.BigDecimal;

public class Controller {
	@FXML
	private Label result;
	@FXML
	private Label track;

	private double number1 = 0;
	private double number2 = 0;
	private String operator = "";
	private boolean point = false;
	private boolean start = true;
	private Model model = new Model();

	@FXML
	public void processNumber(ActionEvent event) {
		if (start && !operator.isEmpty()) {
			result.setText("");
			String value = ((Button) event.getSource()).getText();
			number2 = Double.parseDouble(value);
			result.setText(result.getText() + value);
			track.setText(track.getText() + " " + value);
			start = false;
		} else if (start) {
			result.setText("");
			String value = ((Button) event.getSource()).getText();
			result.setText(value);
			track.setText(value);
			start = false;
		} else if (operator.isEmpty()) {
			String value = ((Button) event.getSource()).getText();
			result.setText(result.getText() + value);
			track.setText(track.getText() + value);
		} else if (point) {
			String value = ((Button) event.getSource()).getText();
			result.setText(result.getText() + value);
			track.setText(track.getText() + value);
		} else if (!operator.isEmpty()) {
			String value = ((Button) event.getSource()).getText();

			if (number2 == 0) {
				number2 = Double.parseDouble(value);
				track.setText(track.getText() + " " + String.valueOf((int) number2));
			} else {
				number2 = model.appendnumber2(Double.parseDouble(value), number2);
				track.setText(track.getText() + value);

			}
			String doubleasString = String.valueOf(number2);
			int indexofDecimal = doubleasString.indexOf(".");
			String substrdaS = doubleasString.substring(indexofDecimal + 1);
			if (Long.parseLong(substrdaS) == 0) {
				result.setText(String.valueOf((int) number2));
			} else if (Long.parseLong(substrdaS) > 0) {
				result.setText(result.getText() + value);
			}
		}
	}

	@FXML
	public void processOperator(ActionEvent event)

	{
		point = false;
		String value = ((Button) event.getSource()).getText();
		String test = String.valueOf(result.getText());
		if (test.contentEquals("")) {
			return;
		}
		if (!value.contentEquals("=")) {
			if (!operator.isEmpty()) {
				number2 = Double.parseDouble(result.getText());
				double output = model.calculate(number1, number2, operator);
				number1 = output;
				number2 = 0;
				operator = value;
				String doubleasString = String.valueOf(output);
				int decimalindex = doubleasString.indexOf(".");
				long substringdaS = Long.parseLong(doubleasString.substring(decimalindex + 1));
				if (substringdaS == 0) {
					result.setText(String.valueOf((int) output));
					track.setText("(" + track.getText() + ")" + " " + value);
				} else if (decimalindex == -1) {
					result.setText(String.valueOf((int) output));
					track.setText("(" + track.getText() + ")" + " " + value);
				} else if (substringdaS > 0) {
					result.setText(String.valueOf(output));
					track.setText("(" + track.getText() + ")" + " " + value);
				}
				start = true;
			} else if (operator.isEmpty()) {
				operator = value;
				number1 = Double.parseDouble(result.getText());
				String doubleasString = String.valueOf(number1);
				int decimalindex = doubleasString.indexOf(".");
				String subdaS = doubleasString.substring(decimalindex + 1);
				if (Long.parseLong(subdaS) == 0) {
					track.setText((String.valueOf((int) number1)) + " " + operator);
				} else {
					track.setText(String.valueOf(number1 + " " + operator));
				}
			}
		} else if (value.contentEquals("=")) {
			if (operator.isEmpty()) {
				return;
			}
			number2 = Double.parseDouble(result.getText());
			double output = model.calculate(number1, number2, operator);
			number1 = output;
			String doubleasString = String.valueOf(output);
			int decimalindex = doubleasString.indexOf(".");
			String substrdaS = doubleasString.substring(decimalindex + 1);
			if (Long.parseLong(substrdaS) == 0) {
				result.setText(String.valueOf((int) output));
				track.setText(track.getText() + " " + value + " " + String.valueOf((int) output));
			} else {
				BigDecimal newoutput = BigDecimal.valueOf(output);
				result.setText(String.valueOf(newoutput));
				track.setText(track.getText() + " " + value + " " + String.valueOf(newoutput));
			}
			value = "";
			operator = "";
			number2 = 0;
			start = true;
		}
	}

	@FXML
	public void processPeriod(ActionEvent Event) {
		point = true;
		String value = result.getText();
		int decimalindex = value.indexOf(".");
		if (start) {
			result.setText("0.");
			track.setText("0.");
			start = false;
		} else if (number2 != 0 && decimalindex == -1) {
			result.setText(result.getText() + ".");
			track.setText(track.getText() + ".");
		} else if (number2 != 0 && decimalindex > 0) {
			return;
		}

		else if (number2 == 0 && decimalindex == -1 && number1 != Double.parseDouble(result.getText())) {
			result.setText(result.getText() + ".");
			track.setText(track.getText() + ".");
		} else if (number2 == 0 && number1 == Double.parseDouble(result.getText())) {
			result.setText("0.");
			result.setText(track.getText() + " " + "0.");
		} else if (number2 == 0 && decimalindex > 0) {
			return;
		}
	}

	@FXML
	public void processClear(ActionEvent event) {
		number1 = 0;
		number2 = 0;
		result.setText("0");
		track.setText("");
		operator = "";
		start = true;
	}

	@FXML
	public void processDel(ActionEvent event) {
		if (start) {
			return;
		}
		String value = result.getText();
		char[] valuearray = value.toCharArray();
		char[] charArray = new char[value.length() - 1];
		for (int i = 0; i < value.length() - 1; i++) {
			charArray[i] = valuearray[i];
		}
		value = String.valueOf(charArray);
		result.setText(value);
		value = track.getText();
		valuearray = value.toCharArray();
		charArray = new char[value.length() - 1];
		for (int i = 0; i < value.length() - 1; i++) {
			charArray[i] = valuearray[i];
		}
		value = String.valueOf(charArray);
		track.setText(value);
	}

	@FXML
	public void processPlusMinus(ActionEvent event) {
		String value = result.getText();
		double signchange = Double.parseDouble(value);
		double newnumber = model.signchange(signchange);
		String doubleasString = String.valueOf(newnumber);
		int decimalindex = doubleasString.indexOf(".");
		double decimalvalue = Double.parseDouble(doubleasString.substring(decimalindex));
		if (decimalvalue == 0) {
			result.setText(String.valueOf((int) newnumber));
		} else {
			result.setText(String.valueOf(newnumber));
		}
	}
}
