package application;

public class Model {
	public double calculate(double number1, double number2, String operator) {
		switch (operator) {
		case "+":
			return number1 + number2;
		case "-":
			return number1 - number2;
		case "*":
			return number1 * number2;
		case "/":
			if (number2 == 0)
				return 0;
			return number1 / number2;
		default:
			return 0; // break
		}
	}

	public double signchange(double number) {
		double newnumber = number * -1;
		return newnumber;
	}

	public double appendnumber2(double value, double number2) {
		double newnumber = number2 * 10 + value;
		return newnumber;
	}
}
